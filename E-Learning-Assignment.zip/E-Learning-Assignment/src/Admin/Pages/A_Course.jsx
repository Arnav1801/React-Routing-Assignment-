import React from 'react'
import A_Header from '../Component/A_Header'



function A_Course() {



  

    return (
        <>
            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> ADD COURSE DATA </h1>
                            <nav aria-label="breadcrumb">
                                {/* <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> */}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-5 bg-info p-5">
                <h2>ADD COURSE </h2>
                <form action="" method='post'>
                    <div className="mb-3 mt-3">
                        <label htmlFor="Coursename"> Course Name:</label>
                        <input type="text" name='CourseName' className="form-control mt-2" placeholder="Course Name"  />
                    </div>
                    <div className="mb-3 mt-3">
                        <label htmlFor="CourseDescription"> Course Description :</label>
                        <input type="text" name='CourseDescription' className="form-control mt-2" placeholder="Course Description"  />
                    </div>
                    <div className="mb-3 mt-3">
                        <label htmlFor="CoursePrice"> Course Price :</label>
                        <input type="text"  name='CoursePrice' className="form-control mt-2" placeholder="Course Price"  />
                    </div>
                    <button type="submit" className="btn btn-danger mt-3">Submit</button>
                </form>
            </div>
        </>
    )
}

export default A_Course