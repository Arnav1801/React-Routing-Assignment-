import React from 'react'
import A_Header from '../Component/A_Header'
import { Helmet } from 'react-helmet'



function M_Course() {

   
 

   


    return (
        <>
            <Helmet>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
            </Helmet>
            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> MANAGE COURSE DATA </h1>
                            <nav aria-label="breadcrumb">
                                {/* <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> */}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container mt-5">
                <h2> List Of Courses </h2>
                <table class="table table-dark table-striped mt-5">
                    <thead>
                        <tr>
                            <th>Course ID </th>
                            <th>Course Name </th>
                            <th> Course Description</th>
                            <th> Cours Price</th>
                           


                        </tr>
                    </thead>
                    <tbody>
                    <tr>
                            <td>1  </td>
                            <td>Graphic Desiging </td>
                            <td> Graphic Desiging </td>
                            <td>80,000/-</td>
                          


                        </tr>
                        <tr>
                            <td>2  </td>
                            <td>Video Editing</td>
                            <td> Video Editing </td>
                            <td>50,000/-</td>
                          


                        </tr>
                        <tr>
                            <td>3  </td>
                            <td>Front-end-Developer</td>
                            <td>Front-end-Developer </td>
                            <td>60,000/-</td>
                          


                        </tr>
                        <tr>
                            <td>4  </td>
                            <td>Full-Stack-Developer</td>
                            <td>Full-Stack-Developer </td>
                            <td>80,000/-</td>
                          


                        </tr>
                    

                    </tbody>
                </table>
            </div >
            {/* <div className="modal" id="myModal">
                <div className="modal-dialog">
                    <div className="modal-content">
                    
                        <div className="modal-header">
                            <h4 className="modal-title"> EDIT COURSE DATA </h4>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" />
                        </div>
                   
                        <div className="modal-body">
                            <form action="" method='post'>
                                <div className="mb-3 mt-3">
                                    <label htmlFor="Coursename"> Course Name:</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.CourseName} name='CourseName' className="form-control mt-2" placeholder="Course Name" />
                                </div>
                                <div className="mb-3 mt-3">
                                    <label htmlFor="CourseDescription"> Course Description :</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.CourseDescription} name='CourseDescription' className="form-control mt-2" placeholder="Course Description" />
                                </div>
                                <div className="mb-3 mt-3">
                                    <label htmlFor="CoursePrice"> Course Price :</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.CoursePrice} name='CoursePrice' className="form-control mt-2" placeholder="Course Price" />
                                </div>

                            </form>
                        </div>
                  
                        <div className="modal-footer">
                            <button type="submit" className="btn btn-danger" data-bs-dismiss="modal" onClick={submitHandel}>Submit </button>
                        </div>
                    </div>
                </div>
            </div>
            <div className="offcanvas offcanvas-top" id="demo" style={{height:500}}>
                <div className="offcanvas-header">
                    <h1 className="offcanvas-title">COURSE DATA </h1>
                    <button type="button" className="btn-close" data-bs-dismiss="offcanvas" />
                </div>
                <div className="offcanvas-body">
                    <form action="" onSubmit={submitHandel} method='post'>
                        <div className="mb-3 mt-3">
                            <label htmlFor="Coursename"> Course Name:</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.CourseName} name='CourseName' className="form-control mt-2" placeholder="Course Name" />
                        </div>
                        <div className="mb-3 mt-3">
                            <label htmlFor="CourseDescription"> Course Description :</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.CourseDescription} name='CourseDescription' className="form-control mt-2" placeholder="Course Description" />
                        </div>
                        <div className="mb-3 mt-3">
                            <label htmlFor="CoursePrice"> Course Price :</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.CoursePrice} name='CoursePrice' className="form-control mt-2" placeholder="Course Price" />
                        </div>

                    </form>
                </div>
            </div> */}
        </>
    )
}

export default M_Course