import React from 'react'
import A_Header from '../Component/A_Header'
import { Helmet } from 'react-helmet'




function M_Employee() {

  
  


    return (
        <>
            <Helmet>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
            </Helmet>

            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> MANAGE EMPLOYEE DATA </h1>
                            <nav aria-label="breadcrumb">
                                {/* <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> */}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-5 bg-info p-5">
                <h2> MANAGE EMPLOYEE DATA </h2>
                <input type='text' className='btn btn-light btn-outline-secondary mt-3 mx-2 float-sm-end mb-5' />
                <button type="button" className="btn btn-light btn-outline-secondary mt-3 float-sm-end">
                    <span className="glyphicon glyphicon-search " />
                    Search
                </button>

                <table className="table mt-5">
                    <thead>
                        <tr>
                            <th> N0.</th>
                            <th> FIRST NAME </th>
                            <th> LAST NAME </th>
                            <th> EMAIL </th>
                            <th> MOBILE NUMBER  </th>
                            <th> EMPLOYEE EDUCATION</th>
                            <th> EMPLOYEE WORK EXPERIENCE </th>
                            <th> LAST JOB ROLE</th>
                          

                        </tr>
                    </thead>
                    <tbody>
                    
                    <tr>
                            <td> 1</td>
                            <td>Arnav</td>
                            <td>Pandav </td>
                            <td>arnav1801@gmail.com </td>
                            <td>9904087778 </td>
                            <td> B.E</td>
                            <td>  5 years</td>
                            <td>Front-end-developer</td>


                        </tr>
                        <tr>
                            <td> 2</td>
                            <td>Dev</td>
                            <td>Prajapati </td>
                            <td>devv1801@gmail.com </td>
                            <td>9904086678 </td>
                            <td> B.A</td>
                            <td>  2 years</td>
                            <td>Full-stack-developer</td>
                        </tr>
                        <tr>
                            <td> 3</td>
                            <td>Yash</td>
                            <td>Soni </td>
                            <td>Soniyash1801@gmail.com </td>
                            <td>9904097659 </td>
                            <td> B.COM</td>
                            <td>  3 years</td>
                            <td>Graphic Designer</td>
                        </tr>
                        <tr>
                            <td> 4</td>
                            <td>Kunal</td>
                            <td>Chauhan </td>
                            <td>Kunal1801@gmail.com </td>
                            <td>9904097239 </td>
                            <td> 12th Pass</td>
                            <td>  5 years</td>
                            <td>Video Editing</td>
                        </tr>
                            

                    

                    </tbody>
                </table>
            </div>
            {/* <div className="modal" id="myModal">
                <div className="modal-dialog">
                    <div className="modal-content">
                   
                        <div className="modal-header">
                            <h4 className="modal-title"> MANAGE EMPLOYEE DATA</h4>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" />
                        </div>
                 
                        <div className="modal-body">

                            <form action="" method='post'>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="Fname"> First Name:</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.FirstName} name='FirstName' class="form-control" placeholder="Enter Employee Name"></input>
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="Lname">Last Name:</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.LastName} name='LastName' class="form-control" placeholder="Enter Employee Surname"></input>
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="email">Email:</label>
                                    <input type="email" onChange={onchangehandel} value={formvalue.email} name='email' className="form-control" id="email" placeholder="Enter Employee email" />
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="mobile "> Mobile Numebr :</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.mobile} name='mobile' class="form-control" placeholder="Enter Employee Number"></input>
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label for="sel1" class="form-label">Select Employee Education:</label>
                                    <select onChange={onchangehandel} value={formvalue.EmployeeEducation} name='EmployeeEducation' class="form-select" id="sel1" >
                                        <option> Select Employee Education </option>
                                        <option> B.C.A </option>
                                        <option> COMPUTER ENGINEERING  </option>
                                        <option> DIPLOMA IN COMPUTER ENGINEERING  </option>
                                        <option> MASTERS IN COMPUTER ENGENEERING  </option>
                                        <option> B.E  </option>
                                    </select>
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label for="sel1" class="form-label">Select Experience :</label>
                                    <select onChange={onchangehandel} value={formvalue.EmployeeWorkExperience} name='EmployeeWorkExperience' class="form-select" id="sel1">
                                        <option> Select Employee Work Experience  </option>
                                        <option> 2 years & More  </option>
                                        <option> 5 years & More  </option>
                                        <option> 10 years & More  </option>
                                        <option> 15 years & More </option>
                                        <option> 25 years & More </option>
                                    </select>
                                </div>
                                <div className="mb-3 mt-3">
                                    <label htmlFor="Last Job role"> Last Job role:</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.LastJobRole} name='LastJobRole' className="form-control" id="pwd" placeholder="Enter Last job role" />
                                </div>

                            </form>
                        </div>
          
                        <div className="modal-footer">
                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal" onClick={submitHandel}>Submit</button>
                        </div>
                    </div>
                </div>
            </div>

            <div className="offcanvas offcanvas-top" id="demo" style={{height:750}}>
                <div className="offcanvas-header">
                    <h1 className="offcanvas-title">MANAGE EMPLOYEE DATA</h1>
                    <button type="button" className="btn-close" data-bs-dismiss="offcanvas" />
                </div>
                <div className="offcanvas-body">
                    <form action="" onSubmit={submitHandel} method='post'>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="Fname"> First Name:</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.FirstName} name='FirstName' class="form-control" placeholder="Enter Employee Name"></input>
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="Lname">Last Name:</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.LastName} name='LastName' class="form-control" placeholder="Enter Employee Surname"></input>
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="email">Email:</label>
                            <input type="email" onChange={onchangehandel} value={formvalue.email} name='email' className="form-control" id="email" placeholder="Enter Employee email" />
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="mobile "> Mobile Numebr :</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.mobile} name='mobile' class="form-control" placeholder="Enter Employee Number"></input>
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label for="sel1" class="form-label">Select Employee Education:</label>
                            <select onChange={onchangehandel} value={formvalue.EmployeeEducation} name='EmployeeEducation' class="form-select" id="sel1" >
                                <option> Select Employee Education </option>
                                <option> B.C.A </option>
                                <option> COMPUTER ENGINEERING  </option>
                                <option> DIPLOMA IN COMPUTER ENGINEERING  </option>
                                <option> MASTERS IN COMPUTER ENGENEERING  </option>
                                <option> B.E  </option>
                            </select>
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label for="sel1" class="form-label">Select Experience :</label>
                            <select onChange={onchangehandel} value={formvalue.EmployeeWorkExperience} name='EmployeeWorkExperience' class="form-select" id="sel1">
                                <option> Select Employee Work Experience  </option>
                                <option> 2 years & More  </option>
                                <option> 5 years & More  </option>
                                <option> 10 years & More  </option>
                                <option> 15 years & More </option>
                                <option> 25 years & More </option>
                            </select>
                        </div>
                        <div className="mb-3 mt-3">
                            <label htmlFor="Last Job role"> Last Job role:</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.LastJobRole} name='LastJobRole' className="form-control" id="pwd" placeholder="Enter Last job role" />
                        </div>
                    </form>
                </div>
            </div> */}



        </>
    )
}

export default M_Employee