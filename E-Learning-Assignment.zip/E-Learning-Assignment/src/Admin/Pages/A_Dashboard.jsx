import React, { useEffect, useState } from 'react'
import A_Header from '../Component/A_Header'
import { Helmet } from 'react-helmet'
import axios from 'axios'

function A_Dashboard() {

    useEffect(() => {
        fetch();
    }, [])

    const [data, setdata] = useState([]);
    const fetch = async () => {
        const result = await axios.get(`https://jsonplaceholder.typicode.com/photos`);
        // console.log(result.data);
        setdata(result.data)
    }

    return (
        <>
            <Helmet>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
            </Helmet>

            <A_Header />

            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> LAZY LOADING  </h1>
                            <nav aria-label="breadcrumb">
                                {/* <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> */}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            {/* < div className="container-fluid" >
                <div className="container">
                    <div className="row">
                        <div className=" col-lg-12 ">
                            <div className="bg-light  p-lg-5">
                                <table className="table">
                                    <thead className="table-dark">
                                        <tr>
                                            <th>Categories ID</th>
                                            <th>Categories Name</th>
                                            <th>Categories Image</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            data && data.map((value) => {
                                                return (
                                                    <tr>
                                                        <td>{value.id}</td>
                                                        <td>{value.title}</td>
                                                        <td> <img src={value.url} alt="" width={50} height={50} /></td>
                                                        <td>
                                                        </td>
                                                    </tr>
                                                )
                                            })
                                        }
                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div > */}

            < div className="container-fluid" >
                <div className="container">
                    <div className="row">

                        <div className=" col-lg-12 ">
                            <div className="bg-light  p-lg-5">


                                <table className="table">
                                    <thead className="table-dark">
                                        <tr>
                                            <th>Categories ID</th>
                                            <th>Categories Name</th>
                                            <th>Categories Image</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {
                                            data && data.map((value) => {
                                                return (
                                                    <tr>
                                                        <td>{value.id}</td>
                                                        <td>{value.title}</td>
                                                        <td> <img src={value.url} alt="" width={50} height={50} /></td>
                                                        <td>
                                                        </td>
                                                    </tr>
                                                )
                                            })
                                        }



                                    </tbody>
                                </table>

                            </div>
                        </div>
                    </div>
                </div>
            </div >









        </>
    )
}

export default A_Dashboard