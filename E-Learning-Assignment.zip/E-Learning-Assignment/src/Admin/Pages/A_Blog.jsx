import React from 'react'
import A_Header from '../Component/A_Header'




function A_Blog() {
   
       

 
    return (
        <>
            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> ADD BLOG DATA </h1>
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-5 bg-info p-5">
                <h2>Blog Page</h2>
                <form action="/action_page.php"  method='post'>
                    <div className="mb-3 mt-5">
                        <label htmlFor="BName"> Blog Title  :</label>
                        <input type="text"  name='BlogName' className="form-control mt-3" id="blog" placeholder="Enter your Blog Title " />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Boffer"> Blog Offer :</label>
                        <input type="text"  name='BlogOffer' className="form-control mt-3" id="blog" placeholder="Enter your Blog Offer" />
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Boffer"> Blog Details :</label>
                        <textarea  name='Blogdetails' class="form-control mt-3" rows="5" id="comment" ></textarea>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="Bimage"> Blog Image :</label>
                        <input type="text"  name='BlogImg' className="form-control mt-3" id="blog" placeholder="Add Image" />
                    </div>
                    <button type="submit" className="btn btn-success mt-3 ">ADD </button>
                </form>
            </div>


        </>
    )
}

export default A_Blog