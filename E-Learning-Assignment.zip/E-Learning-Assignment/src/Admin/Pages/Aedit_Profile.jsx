import React from 'react'
import axios from 'axios';

import A_Header from '../Component/A_Header';
import { Helmet } from 'react-helmet';

function Aedit_Profile() {
    

  return (
    <>
    <Helmet>
    {/* <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"/> */}
    </Helmet>
    <A_Header/> 
    <div style={{ backgroundImage: "URL('https://img.freepik.com/free-vector/e-learning-education-template-vector-technology-ad-banner_53876-125996.jpg')", backgroundSize: 'cover', backgroundRepeat: 'no-repeat', height: '100vh' }} className='p-5'>
                <div className="container p-5" style={{ backgroundColor: 'rgb(240, 241, 237)', opacity: '0.9', width: 600, marginTop: 120 }}>
                    <h2> EDIT PROFILE </h2>
                    <form action="/action_page.php" method="post" >
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="name"> Name:</label>
                            <input type="text"  name='name' class="form-control mt-2" placeholder="Enter Name"></input>
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="mobile "> Mobile Numebr :</label>
                            <input type="text"  name='mobile' class="form-control mt-2" placeholder="Enter Number"></input>
                        </div>
                        <div className="mb-3 mt-3">
                            <label htmlFor="email">Email:</label>
                            <input type="email" name='email' className="form-control mt-2" id="email" placeholder="Enter email" />
                        </div>
                        <div className="mb-3 mt-3">
                            <label htmlFor="email">Profile Image:</label>
                            <input type="url" name='ProfileImage' className="form-control mt-2" id="email" placeholder="Upload Profile" />
                        </div>
                        <button type="submit" className="btn btn-secondary"> Update </button>
                    </form>
                </div>
            </div>
    </>
  )
}

export default Aedit_Profile