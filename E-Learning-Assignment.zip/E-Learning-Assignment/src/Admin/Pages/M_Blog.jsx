import React from 'react'
import A_Header from '../Component/A_Header'


import { Helmet } from 'react-helmet'


function M_Blog() {


  return (
    <>
      <Helmet>
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
      </Helmet>
      <A_Header />
      <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
        <div className="container py-5">
          <div className="row justify-content-center">
            <div className="col-lg-10 text-center">
              <h1 className="display-3 text-white animated slideInDown"> MANAGE BLOG DATA </h1>
              <nav aria-label="breadcrumb">
                <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> 
              </nav>
            </div>
          </div>
        </div>
      </div>
      <div className="container mt-5 bg-info p-5 mw-100" style={{ width: 1200 }}>
        <button type="button" class="btn btn-success">Manage Post</button>
        <table class="table mt-5">
          <thead>
            <tr>
              <th>ID</th>
              <th>Blog Name</th>
              <th>Blog Offer</th>
              <th>Blog Details</th>
              <th>Blog Img</th>
              <th> EDIT </th>
              <th> VIEW</th>
              <th> DELETE</th>

            </tr>
          </thead>
          <tbody>
          <tr>
              <th>ID</th>
              <th>Blog Name</th>
              <th>Blog Offer</th>
              <th>Blog Details</th>
              <th>Blog Img</th>
              <th> EDIT </th>
              <th> VIEW</th>
              <th> DELETE</th>

            </tr>

          </tbody>
        </table>

      </div>
      {/* <div className="modal" id="myModal">
        <div className="modal-dialog">
          <div className="modal-content">
          
            <div className="modal-header">
              <h4 className="modal-title"> MANAGE BLOG DATA</h4>
              <button type="button" className="btn-close" data-bs-dismiss="modal" />
            </div>
   
            <div className="modal-body">
              <form action="/action_page.php" method='post'>
                <div className="mb-3 mt-5">
                  <label htmlFor="BName"> Blog Title  :</label>
                  <input type="text" onChange={onchangehandel} value={formvalue.BlogName} name='BlogName' className="form-control mt-3" id="blog" placeholder="Enter your Blog Title " />
                </div>
                <div className="mb-3">
                  <label htmlFor="Boffer"> Blog Offer :</label>
                  <input type="text" onChange={onchangehandel} value={formvalue.BlogOffer} name='BlogOffer' className="form-control mt-3" id="blog" placeholder="Enter your Blog Offer" />
                </div>
                <div className="mb-3">
                  <label htmlFor="Boffer"> Blog Details :</label>
                  <textarea onChange={onchangehandel} value={formvalue.Blogdetails} name='Blogdetails' class="form-control mt-3" rows="5" id="comment" ></textarea>
                </div>
                <div className="mb-3">
                  <label htmlFor="Bimage"> Blog Image :</label>
                  <input type="text" onChange={onchangehandel} value={formvalue.BlogImg} name='BlogImg' className="form-control mt-3" id="blog" placeholder="Add Image" />
                </div>

              </form>
            </div>
          
            <div className="modal-footer">
              <button type="button" className="btn btn-danger" data-bs-dismiss="modal" onClick={submitHandel}>Submit</button>
            </div>
          </div>
        </div>
      </div>
      <div>

        <div className="offcanvas offcanvas-start " id="demo" style={{ width: 500 }}>
          <div className="offcanvas-header mx-5 mt-5">
            <h1 className="offcanvas-title ">{formvalue.BlogName} </h1>
            <button type="button" className="btn-close" data-bs-dismiss="offcanvas" />
          </div>
          <div className="offcanvas-body mx-5">
            <div className="card" style={{ width: 400 , height: 400}}>
              <img className="card-img-top" src={formvalue.BlogImg} alt="Card image" style={{ width: '100%' }} />
              <div className="card-body">
                <h4 className="card-title">{formvalue.BlogOffer}</h4>
                <p className="card-text">{formvalue.Blogdetails}</p>
              </div>
            </div>
          </div>
        </div>
      </div> */}
    </>
  )
}

export default M_Blog