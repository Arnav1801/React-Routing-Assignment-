import React from 'react'
import A_Header from '../Component/A_Header'

import { Helmet } from 'react-helmet'




function A_Contact() {





    return (
        <>
            <Helmet>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
            </Helmet>
            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> CONTACT PAGE</h1>
                            <nav aria-label="breadcrumb">
                                <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol>
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-5 bg-info text-dark p-5">
                <h2>CONTACT ENQUIRY </h2>
                <table className="table mt-5" border={1}>
                    <thead className="table-dark">
                        <tr>
                            <th><input type="checkbox" class="form-check-input" id="check2" name="option2" value="something" /> </th>
                            <th>Name</th>
                            <th>Email </th>
                            <th>Subject </th>
                            <th>Message  </th>
                         
                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <th><input type="checkbox" class="form-check-input" id="check2" name="option2" value="something" /> </th>
                            <td>Arnav</td>
                            <td>arnav1801@gmail.com</td>
                            <td>About Front-end- Course</td>
                            <td>About Front-end- Course </td>
                         
                        </tr>
                        <tr>
                            <th><input type="checkbox" class="form-check-input" id="check2" name="option2" value="something" /> </th>
                            <td>Dev</td>
                            <td>Dev1801@gmail.com</td>
                            <td>About Full-Stack- Course</td>
                            <td>About Front-Stack- Course </td>
                         
                        </tr>
                    </tbody>

                </table>

            </div>

        </>
    )
}

export default A_Contact