import React from 'react'
import A_Header from '../Component/A_Header'
import { Helmet } from 'react-helmet'


function Manage_Employee() {


    return (
        <>
            <Helmet>
                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
            </Helmet>

            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> MANAGE EMPLOYEE  </h1>
                            <nav aria-label="breadcrumb">
                                {/* <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> */}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-5 bg-info p-5">
                <h2> EMPLOYEE DATA </h2>
                <input type='text' className='btn btn-light btn-outline-secondary mt-3 mx-2 float-sm-end mb-5' />
                <button type="button" className="btn btn-light btn-outline-secondary mt-3 float-sm-end">
                    <span className="glyphicon glyphicon-search " />
                    Search
                </button>
                <table className="table mt-5">
                    <thead>
                        <tr>
                            <th> ID</th>
                            <th> FIRST NAME</th>
                            <th> LAST NAME</th>
                            <th>EMAIL </th>
                            <th>MOBILE NUMBER </th>
                            <th> EMPLOYEE EDUCATION</th>
                            <th> EMPLOYEE WORK EXPERIENCE</th>
                            <th> LAST JOB ROLE</th>
                            <th> ACTION </th>

                        </tr>
                    </thead>
                    <tbody>

                        <tr>
                            <td> 1</td>
                            <td>Arnav</td>
                            <td>Pandav </td>
                            <td>arnav1801@gmail.com </td>
                            <td>9904087778 </td>
                            <td> B.E</td>
                            <td>Front-end-developer</td>

                        </tr>
                        <tr>
                            <td> 2</td>
                            <td>Dev</td>
                            <td>Prajapati </td>
                            <td>devv1801@gmail.com </td>
                            <td>9904086678 </td>
                            <td> B.A</td>
                            <td>Full-stack-developer</td>
                        </tr>
                        <tr>
                            <td> 3</td>
                            <td>Yash</td>
                            <td>Soni </td>
                            <td>Soniyash1801@gmail.com </td>
                            <td>9904097659 </td>
                            <td> B.COM</td>
                            <td>Graphic Designer</td>
                        </tr>
                        <tr>
                            <td> 4</td>
                            <td>Kunal</td>
                            <td>Chauhan </td>
                            <td>Kunal1801@gmail.com </td>
                            <td>9904097239 </td>
                            <td> 12th Pass</td>
                            <td>Video Editing</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </>
    )
}

export default Manage_Employee