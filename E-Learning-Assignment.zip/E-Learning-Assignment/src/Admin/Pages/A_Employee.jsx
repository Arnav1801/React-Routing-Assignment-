import React from 'react'
import A_Header from '../Component/A_Header'



function A_Employee() {


    return (
        <>
            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> ADD EMPLOYEE DATA </h1>
                            <nav aria-label="breadcrumb">
                                {/* <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> */}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-5 bg-info text-dark p-5">
                <h2 className=''> EMPLOYEE ENTRY FORM </h2>
                <form action=""  method='post'>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="Fname"> First Name:</label>
                        <input type="text"  name='FirstName' class="form-control" placeholder="Enter Employee Name"></input>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="Lname">Last Name:</label>
                        <input type="text"  name='LastName' class="form-control" placeholder="Enter Employee Surname"></input>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="email">Email:</label>
                        <input type="email"  name='email' className="form-control" id="email" placeholder="Enter Employee email" />
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="mobile "> Mobile Numebr :</label>
                        <input type="text" name='mobile' class="form-control" placeholder="Enter Employee Number"></input>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label for="sel1" class="form-label">Select Employee Education:</label>
                        <select  name='EmployeeEducation' class="form-select" id="sel1" >
                            <option> Select Employee Education </option>
                            <option> B.C.A </option>
                            <option> COMPUTER ENGINEERING  </option>
                            <option> DIPLOMA IN COMPUTER ENGINEERING  </option>
                            <option> MASTERS IN COMPUTER ENGENEERING  </option>
                            <option> B.E  </option>
                        </select>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label for="sel1" class="form-label">Select Experience :</label>
                        <select name='EmployeeWorkExperience' class="form-select" id="sel1">
                            <option> Select Employee Work Experience  </option>
                            <option> 2 years & More  </option>
                            <option> 5 years & More  </option>
                            <option> 10 years & More  </option>
                            <option> 15 years & More </option>
                            <option> 25 years & More </option>
                        </select>
                    </div>
                    <div className="mb-3 mt-3">
                        <label htmlFor="Last Job role"> Last Job role:</label>
                        <input type="text" name='LastJobRole' className="form-control" id="pwd" placeholder="Enter Last job role" />
                    </div>

                    <button type="submit" className="btn btn-secondary mt-5">Submit</button>
                </form>
            </div>


        </>
    )
}

export default A_Employee