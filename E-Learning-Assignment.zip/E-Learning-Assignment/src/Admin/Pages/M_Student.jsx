import React from 'react'
import A_Header from '../Component/A_Header'
import { Helmet } from 'react-helmet'

function M_Student() {

    return (
        <>
            <Helmet>


                <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css" />
            </Helmet>

            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> MANAGE STUDENT DATA </h1>
                            <nav aria-label="breadcrumb">
                                {/* <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> */}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-5 bg-info p-5">
                <h2> STUDENT DATA </h2>
                <input type='text' className='btn btn-light btn-outline-secondary mt-3 mx-2 float-sm-end mb-5' />
                <button type="button" className="btn btn-light btn-outline-secondary mt-3 float-sm-end">
                    <span className="glyphicon glyphicon-search " />
                    Search
                </button>
                <table className="table mt-5">
                    <thead>
                        <tr>
                            <th> ID</th>
                            <th>FIRST NAME</th>
                            <th>LAST NAME </th>
                            <th>EMAIL </th>
                            <th>MOBILE NUMBER </th>
                            <th>STUDENT IMAGE </th>
                            <th>COURSE</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td> 1</td>
                            <td>Arnav</td>
                            <td>Pandav </td>
                            <td>arnav1801@gmail.com </td>
                            <td>9904087778 </td>
                            <td> B.E</td>
                            <td>Front-end-developer</td>
                        </tr>
                        <tr>
                            <td> 2</td>
                            <td>Dev</td>
                            <td>Prajapati </td>
                            <td>devv1801@gmail.com </td>
                            <td>9904086678 </td>
                            <td> B.A</td>
                            <td>Full-stack-developer</td>
                        </tr>
                        <tr>
                            <td> 3</td>
                            <td>Yash</td>
                            <td>Soni </td>
                            <td>Soniyash1801@gmail.com </td>
                            <td>9904097659 </td>
                            <td> B.COM</td>
                            <td>Graphic Designer</td>
                        </tr>
                        <tr>
                            <td> 4</td>
                            <td>Kunal</td>
                            <td>Chauhan </td>
                            <td>Kunal1801@gmail.com </td>
                            <td>9904097239 </td>
                            <td> 12th Pass</td>
                            <td>Video Editing</td>
                        </tr>
                    </tbody>
                </table>
            </div>

            {/* <div className="modal" id="myModal">
                <div className="modal-dialog">
                    <div className="modal-content">
                   
                        <div className="modal-header">
                            <h4 className="modal-title"> MANAGE STUDENT DATA</h4>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" />
                        </div>
           
                   
                        <div className="modal-body">
                            <form action="" method='post'>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="Fname"> First Name:</label>

                                    <input type="text" onChange={onchangehandel} value={formvalue.FirstName} name='FirstName' class="form-control mt-2" placeholder="Enter Student Name"></input>
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="Lname">Last Name:</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.LastName} name='LastName' class="form-control mt-2" placeholder="Enter Student Surname"></input>
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="email">Email:</label>
                                    <input type="email" onChange={onchangehandel} value={formvalue.email} name='email' className="form-control" id="email" placeholder="Enter Student email" />
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="mobile "> Mobile Numebr :</label>
                                    <input type="text" onChange={onchangehandel} value={formvalue.mobile} name='mobile' class="form-control mt-2" placeholder="Enter Student Contact" ></input>
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label htmlFor="Student Image "> Student Image :</label>
                                    <input type="url" onChange={onchangehandel} value={formvalue.StudentImage} name='StudentImage' class="form-control mt-2" placeholder="Upload Student Image " ></input>
                                </div>
                                <div className="mb-3 mt-3 ">
                                    <label for="sel1" class="form-label">Select Student Education:</label>
                                    <select onChange={onchangehandel} value={formvalue.StudentEducation} name='StudentEducation' class="form-select mt-2" id="sel1">
                                        <option value=""> Select Student Education </option>
                                        <option>10th PASS </option>
                                        <option>12th PASS </option>
                                    </select>
                                </div> 
                                <div className="mb-3 mt-3 ">
                                    <label for="sel1" class="form-label">Select Course:</label>
                                    <select onChange={onchangehandel} value={formvalue.Course_id} name="Course_id" className="form-control"  >

                                        <option value="">Select Course TYPE</option>
                                        {

                                            cdata && cdata.map((value) => {
                                                return (
                                                  
                                                    <option key={value.id} value={value.CourseName}>{value.CourseName} </option>
                                                )
                                            }
                                            )

                                        }

                                    </select>
                                </div>


                                <div className="mb-3 mt-3 ">
                                    <label for="sel1" class="form-label">Select Student Course:</label>
                                    <select onChange={onchangehandel} value={formvalue.StudentCourse} name='StudentCourse' class="form-select mt-2" id="sel1">
                                        <option value=""> Select Student Course </option>
                                        <option>GRAPHIC DESIGNING </option>
                                        <option>FROND-END DEVELOPER </option>
                                        <option> BACK-END DEVELOPER </option>
                                        <option>MULTIMEDIA  </option>
                                        <option>VIDEO EDITING  </option>
                                        <option>FIGMA </option>
                                        <option>SOFTWARE TESTING</option>
                                    </select>
                                </div>

                            </form>
                        </div>
        
                        <div className="modal-footer">
                            <button type="button" className="btn btn-danger" data-bs-dismiss="modal" onClick={submitHandel}>Submit</button>
                        </div>
                    </div>
                </div>
            </div>


            <div className="offcanvas offcanvas-top" id="demo" style={{ height: 700 }}>
                <div className="offcanvas-header">
                    <h1 className="offcanvas-title">STUDENT DATA </h1>
                    <button type="button" className="btn-close btn-close-dark" data-bs-dismiss="offcanvas" />
                </div>
                <div className="offcanvas-body">

                    <form action="" onSubmit={submitHandel} method='post'>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="Fname"> First Name:  <span> {formvalue.FirstName} </span> </label>

                        </div>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="Lname">Last Name:</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.LastName} name='LastName' class="form-control mt-2" placeholder="Enter Student Surname"></input>
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="email">Email:</label>
                            <input type="email" onChange={onchangehandel} value={formvalue.email} name='email' className="form-control" id="email" placeholder="Enter Student email" />
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="mobile "> Mobile Numebr :</label>
                            <input type="text" onChange={onchangehandel} value={formvalue.mobile} name='mobile' class="form-control mt-2" placeholder="Enter Student Contact" ></input>
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label htmlFor="Student Image "> Student Image :</label>
                            <input type="url" onChange={onchangehandel} value={formvalue.StudentImage} name='StudentImage' class="form-control mt-2" placeholder="Upload Student Image " ></input>
                        </div>
                        <div className="mb-3 mt-3 ">
                            <label for="sel1" class="form-label">Select Student Education:</label>
                            <select onChange={onchangehandel} value={formvalue.StudentEducation} name='StudentEducation' class="form-select mt-2" id="sel1">
                                <option value=""> Select Student Education </option>
                                <option>10th PASS </option>
                                <option>12th PASS </option>
                                <option> B.A </option>
                                <option>B.COM </option>
                                <option>B.C.A </option>
                                <option>DIPLOMA IN ANY FIELD </option>
                                <option>DEGREE IN ANY FIELD</option>
                            </select>
                        </div>
                       
                 
                        <div className="mb-3 mt-3 ">
                            <label for="sel1" class="form-label">Select Student Course:</label>
                            <select onChange={onchangehandel} value={formvalue.StudentCourse} name='StudentCourse' class="form-select mt-2" id="sel1">
                                <option value=""> Select Student Course </option>
                                <option>GRAPHIC DESIGNING </option>
                                <option>FROND-END DEVELOPER </option>
                                <option> BACK-END DEVELOPER </option>
                                <option>MULTIMEDIA  </option>
                                <option>VIDEO EDITING  </option>
                                <option>FIGMA </option>
                                <option>SOFTWARE TESTING</option>
                            </select>
                        </div>

                    </form>


                </div>
            </div> */}


        </>
    )
}

export default M_Student