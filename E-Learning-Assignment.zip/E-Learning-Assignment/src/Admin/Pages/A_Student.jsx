import React from 'react'
import A_Header from '../Component/A_Header'
import { Helmet } from 'react-helmet'



function A_Student() {


    return (
        <>
            <Helmet>
                <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" />
                <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
            </Helmet>
            <A_Header />
            <div className="container-fluid bg-primary py-5 mb-5 mt-2 page-header">
                <div className="container py-5">
                    <div className="row justify-content-center">
                        <div className="col-lg-10 text-center">
                            <h1 className="display-3 text-white animated slideInDown"> ADD STUDENT DATA  </h1>
                            <nav aria-label="breadcrumb">
                                {/* <ol className="breadcrumb justify-content-center">
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Dashboard</a></li>
                                    <li className="breadcrumb-item"><a className="text-white" href="#"> Student </a></li>
                                    <li className="breadcrumb-item text-white active" aria-current="page"> Employee</li>
                                </ol> */}
                            </nav>
                        </div>
                    </div>
                </div>
            </div>
            <div className="container mt-5 bg-info text-dark p-5">
                <h2 className=''>STUDENT ENTRY FORM </h2>
                <form action="" method='post'>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="Fname"> First Name:</label>
                        <input type="text" name='FirstName' class="form-control mt-2" placeholder="Enter Student Name"></input>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="Lname">Last Name:</label>
                        <input type="text"  name='LastName' class="form-control mt-2" placeholder="Enter Student Surname"></input>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="email">Email:</label>
                        <input type="email"  name='email' className="form-control" id="email" placeholder="Enter Student email" />
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="mobile "> Mobile Numebr :</label>
                        <input type="text"  name='mobile' class="form-control mt-2" placeholder="Enter Student Contact" ></input>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label htmlFor="Student Image "> Student Image :</label>
                        <input type="url"  name='StudentImage' class="form-control mt-2" placeholder="Upload Student Image " ></input>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label for="sel1" class="form-label">Select Student Education:</label>
                        <select  name='StudentEducation' class="form-select mt-2" id="sel1">
                            <option value=""> Select Student Education </option>
                            <option>10th PASS </option>
                            <option>12th PASS </option>
                            <option> B.A </option>
                            <option>B.COM </option>
                            <option>B.C.A </option>
                            <option>DIPLOMA IN ANY FIELD </option>
                            <option>DEGREE IN ANY FIELD</option>
                        </select>
                    </div>
                    <div className="mb-3 mt-3 ">
                        <label for="sel1" class="form-label">Select Student Course:</label>
                        <select  name='StudentCourse' class="form-select mt-2" id="sel1">
                            <option value=""> Select Student Course </option>
                            <option>GRAPHIC DESIGNING </option>
                            <option>FROND-END DEVELOPER </option>
                            <option> BACK-END DEVELOPER </option>
                            <option>MULTIMEDIA  </option>
                            <option>VIDEO EDITING  </option>
                            <option>FIGMA </option>
                            <option>SOFTWARE TESTING</option>
                        </select>
                    </div>
                    {/* <div className="mb-3 mt-3 ">
                        <label for="sel1" class="form-label">Select Course:</label>
                        <select name="Course_id" className="form-control"  >

                        </select>
                    </div> */}
                    <button type="submit" className="btn btn-secondary mt-5">Submit</button>
                </form>
            </div>


        </>
    )
}

export default A_Student